import tkinter as tk
import random

#変数==============================================================
turn_player = "black"
is_moved = False
is_gaming = True
is_checked = False
#関数==============================================================
def observeMethod():
    global is_gaming
    global is_checked
    if watch_button["text"] == "観測":
        for y in range(0, 15):
            for x in range(0, 15):
                if mass[y][x].state == "decided":
                    resurt = random.randint(1, 100)
                    if mass[y][x].percent >= resurt:
                        mass[y][x].label['image'] = black_image
                        mass[y][x].color = "black"
                    else:
                        mass[y][x].label['image'] = white_image
                        mass[y][x].color = "white"
        winCheckMethod()
        if is_gaming:
            watch_button["text"] = "戻す"
        turn_button["state"] = "disabled"
        is_checked = True
    else:
        for y in range(0, 15):
            for x in range(0, 15):
                if mass[y][x].state == "decided":
                    mass[y][x].label['image'] = percents[mass[y][x].percent]
                    mass[y][x].color = "gray"
        watch_button["text"] = "観測"
        turn_button["state"] = "active"
        if is_checked:
            watch_button["state"] = "disabled"

def turnMethod():
    global turn_player
    global is_moved
    if is_moved and watch_button["text"] == "観測" and is_gaming:
        if turn_player == "black":
            turn_player = "white"
            turn_label["text"] = "手番:白"
            white_frame["bg"] = "yellow"
            black_frame["bg"] = "#f0f0f0"
        else:
            turn_player = "black"
            turn_label["text"] = "手番:黒"
            black_frame["bg"] = "yellow"
            white_frame["bg"] = "#f0f0f0"

        for y in range(0, 15):
            for x in range(0, 15):
                if mass[y][x].state == "decided":
                    mass[y][x].label['image'] = percents[mass[y][x].percent]
                    mass[y][x].color = "gray"
        is_moved = False
        turn_button["state"] = "disabled"
        if watch_button["state"] == "active":
            watch_button["state"] = "disabled"


def winCheckMethod():
    win_black = False
    win_white = False

    blacks = []
    black_count = 0
    #横黒------------------------------------------------
    for y in range(0, 15):
        if black_count == 5:
            break
        blacks = []
        black_count = 0
        for x in range(0, 15):
            if mass[y][x].color == "black":
                blacks.append({"x":x, "y":y})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for i in range(0, 5):
                    mass[blacks[i]["y"]][blacks[i]["x"]].label['image'] = complete_black_image
                win_black =  True
                break
    #縦黒------------------------------------------------
    for x in range(0, 15):
        if win_black:
            break
        blacks = []
        black_count = 0
        for y in range(0, 15):
            if mass[y][x].color == "black":
                blacks.append({"x":x, "y":y})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for i in range(0, 5):
                    mass[blacks[i]["y"]][blacks[i]["x"]].label['image'] = complete_black_image
                win_black =  True
                break
    #左上斜め黒------------------------------------------------
    for i in range(0, 15):
        if win_black:
            break
        blacks = []
        black_count = 0
        for j in range(0, 1+i):
            if mass[i-j][j].color == "black":
                blacks.append({"x":j, "y":i-j})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for z in range(0, 5):
                    mass[blacks[z]["y"]][blacks[z]["x"]].label['image'] = complete_black_image
                win_black =  True
                break
    #右上斜め黒------------------------------------------------
    for i in range(0, 15):
        if win_black:
            break
        blacks = []
        black_count = 0
        for j in range(0, 1+i):
            if mass[j][14-i+j].color == "black":
                blacks.append({"x":14-i+j, "y":j})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for z in range(0, 5):
                    mass[blacks[z]["y"]][blacks[z]["x"]].label['image'] = complete_black_image
                win_black =  True
                break
    #左下斜め黒------------------------------------------------
    for i in range(0, 15):
        if win_black:
            break
        blacks = []
        black_count = 0
        for j in range(0, 1+i):
            if mass[14-i+j][j].color == "black":
                blacks.append({"x":j, "y":14-i+j})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for z in range(0, 5):
                    mass[blacks[z]["y"]][blacks[z]["x"]].label['image'] = complete_black_image
                win_black =  True
                break
     #右下斜め黒------------------------------------------------
    for i in range(0, 15):
        if win_black:
            break
        blacks = []
        black_count = 0
        for j in range(0, 1+i):
            if mass[14-j][14-i+j].color == "black":
                blacks.append({"x":14-i+j, "y":14-j})
                black_count += 1
            else:
                blacks = []
                black_count = 0
            if black_count == 5:
                for z in range(0, 5):
                    mass[blacks[z]["y"]][blacks[z]["x"]].label['image'] = complete_black_image
                win_black =  True
                break

    whites = []
    white_count = 0
    #横白------------------------------------------------
    for y in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for x in range(0, 15):
            if mass[y][x].color == "white":
                whites.append({"x":x, "y":y})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for i in range(0, 5):
                    mass[whites[i]["y"]][whites[i]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
    #縦白------------------------------------------------
    for x in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for y in range(0, 15):
            if mass[y][x].color == "white":
                whites.append({"x":x, "y":y})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for i in range(0, 5):
                    mass[whites[i]["y"]][whites[i]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
    #左上斜め白------------------------------------------------
    for i in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for j in range(0, 1+i):
            if mass[i-j][j].color == "white":
                whites.append({"x":j, "y":i-j})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for z in range(0, 5):
                    mass[whites[z]["y"]][whites[z]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
    #右上斜め白------------------------------------------------
    for i in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for j in range(0, 1+i):
            if mass[j][14-i+j].color == "white":
                whites.append({"x":14-i+j, "y":j})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for z in range(0, 5):
                    mass[whites[z]["y"]][whites[z]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
    #左下斜め白------------------------------------------------
    for i in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for j in range(0, 1+i):
            if mass[14-i+j][j].color == "white":
                whites.append({"x":j, "y":14-i+j})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for z in range(0, 5):
                    mass[whites[z]["y"]][whites[z]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
     #右下斜め白------------------------------------------------
    for i in range(0, 15):
        if win_white:
            break
        whites = []
        white_count = 0
        for j in range(0, 1+i):
            if mass[14-j][14-i+j].color == "white":
                whites.append({"x":14-i+j, "y":14-j})
                white_count += 1
            else:
                whites = []
                white_count = 0
            if white_count == 5:
                for z in range(0, 5):
                    mass[whites[z]["y"]][whites[z]["x"]].label['image'] = complete_white_image
                win_white =  True
                break
    
    if win_black and not(win_white):
        winner_label["text"] = "黒の勝利！！！"
    elif not(win_black) and win_white:
        winner_label["text"] = "白の勝利！！！"
    elif win_black and win_white:
        global turn_player
        if turn_player == "black":
            winner_label["text"] = "黒の勝利！！！"
        elif turn_player == "white":
            winner_label["text"] = "白の勝利！！！"
    
    if win_black or win_white:
        global is_gaming
        is_gaming = False
        watch_button["state"] = "disabled"
        turn_button["state"] = "disabled"

def reMethod():
    for y in range(0, 15):
        for x in range(0, 15):
            mass[y][x].label['image'] = mass_image
            mass[y][x].state = "unselect"
            mass[y][x].percent = 0
            mass[y][x].color = "gray"

    global turn_player
    global is_moved
    global is_gaming
    turn_player = "black"
    turn_label["text"] = "手番:黒"
    black_frame["bg"] = "yellow"
    white_frame["bg"] = "#f0f0f0"
    is_moved = False
    is_gaming = True
    watch_button["text"] = "観測"
    watch_button["state"] = "disabled"
    turn_button["state"] = "disabled"
    radio90["state"] = 'active'
    black_var.set(90)
    radio10["state"] = 'active'
    white_var.set(10)
    winner_label["text"] = "勝負中..."

class panel:
    def __init__(self, x_point, y_point, label):
        self.x_point = x_point
        self.y_point = y_point
        self.label = label
        self.state = "unselect"
        self.percent = 0
        self.color = "gray"
        
    def enterMethod(self,event):
        global is_gaming
        if watch_button["text"] == "観測" and is_gaming:
            if self.state != "selected" and self.state != "decided":
                self.label['image'] = enter_image

    def leaveMethod(self,event):
        global is_gaming
        if watch_button["text"] == "観測" and is_gaming:
            if self.state != "selected" and self.state != "decided":
                self.state = "unselect"
                self.label['image'] = mass_image

    def selectMethod(self,event):
        global is_moved
        global is_gaming
        if watch_button["text"] == "観測" and not(is_moved) and is_gaming:
            if self.state != "selected" and self.state != "decided":
                for y in range(0, 15):
                    for x in range(0, 15):
                        if mass[y][x].state == "selected":
                            mass[y][x].state = "unselect"
                            mass[y][x].label['image'] = mass_image
                self.state = "selected"
                self.label['image'] = selected_image
            elif self.state == "selected":
                global turn_player
                if turn_player == "black":
                    self.state = "decided"
                    self.label['image'] = percents[black_var.get()]
                    self.percent = black_var.get()
                    if black_var.get() == 90:
                        radio90["state"] = 'disabled'
                        black_var.set(70)
                    elif black_var.get() == 70 and radio90["state"] == 'disabled':
                        radio90["state"] = 'active'
                        black_var.set(90)
                elif turn_player == "white":
                    self.state = "decided"
                    self.label['image'] = percents[white_var.get()]
                    self.percent = white_var.get()
                    if white_var.get() == 10:
                        radio10["state"] = 'disabled'
                        white_var.set(30)
                    elif white_var.get() == 30 and radio10["state"] == 'disabled':
                        radio10["state"] = 'active'
                        white_var.set(10)
                is_moved = True
                watch_button["state"] = "active"
                turn_button["state"] = "active"




#メイン==============================================================
game_w = tk.Tk()
game_w.title("量子五目並べ")
game_w.geometry("1500x1000")
game_w.resizable(False,False)

#画像インスタンス--------------------------------------------------
mass_image = tk.PhotoImage(file = "image/mass.png")
percents = {}
percents[90] = tk.PhotoImage(file = "image/90%.png")
percents[70] = tk.PhotoImage(file = "image/70%.png")
percents[10] = tk.PhotoImage(file = "image/10%.png")
percents[30] = tk.PhotoImage(file = "image/30%.png")
enter_image = tk.PhotoImage(file = "image/enter.png")
selected_image = tk.PhotoImage(file = "image/selected.png")
black_image = tk.PhotoImage(file = "image/black.png")
white_image = tk.PhotoImage(file = "image/white.png")
complete_black_image = tk.PhotoImage(file = "image/complete_black.png")
complete_white_image = tk.PhotoImage(file = "image/complete_white.png")

board_frame = tk.Frame(game_w)
board_frame.pack(side = tk.LEFT, padx=(30,0), ipadx=0)

alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O"]
ippen = 46


col_num = []
for x in range(0, 15):
    col_num.append({})
    col_num[x]["image"] = tk.PhotoImage(file = "image/"+alphabet[x]+".png")
    col_num[x]["label"] = tk.Label(board_frame, width=ippen, height=ippen, image=col_num[x]["image"])
    col_num[x]["label"].grid(row=0, column=x+1)

row_num = []
for y in range(0, 15):
    row_num.append({})
    row_num[y]["image"] = tk.PhotoImage(file = "image/"+str(y+1)+".png")
    row_num[y]["label"] = tk.Label(board_frame, width=ippen, height=ippen, image=row_num[y]["image"])
    row_num[y]["label"].grid(row=y+1, column=0)

mass = []
for y in range(0, 15):
    mass.append([])
    for x in range(0, 15):
        mass[y].append(panel(x, y, tk.Label(board_frame, width=ippen, height=ippen, image=mass_image, anchor="center")))
        mass[y][x].label.grid(row=y+1, column=x+1)
        mass[y][x].label.bind("<Enter>", mass[y][x].enterMethod)
        mass[y][x].label.bind("<Leave>", mass[y][x].leaveMethod)
        mass[y][x].label.bind("<ButtonPress>", mass[y][x].selectMethod)

select_frame = tk.Frame(game_w, relief= tk.SOLID, bd=1)
select_frame.pack(side = tk.RIGHT, padx=(0,100))

winner_label = tk.Label(select_frame, text="勝負中...", font = ("", "50"))
winner_label.pack(side = tk.TOP, padx=30, pady=(30,0))

turn_label = tk.Label(select_frame, text="手番:黒", font = ("", "20"))
turn_label.pack(side = tk.TOP, padx=30, pady=(30,0))

#黒側選択-----------------------------------------------------
black_var = tk.IntVar()
black_var.set(90)

black_frame = tk.Frame(select_frame, relief= tk.SOLID, bd=1, bg="yellow")
black_frame.pack(side = tk.TOP, padx=30, pady=(30,0))

radio90 = tk.Radiobutton(black_frame, image=percents[90], variable=black_var, value=90)
radio90.pack(side = tk.LEFT, padx=(0,200))
radio70 = tk.Radiobutton(black_frame, image=percents[70], variable=black_var, value=70)
radio70.pack(side = tk.LEFT)
#白側選択-----------------------------------------------------
white_var = tk.IntVar()
white_var.set(10)

white_frame = tk.Frame(select_frame, relief= tk.SOLID, bd=1)
white_frame.pack(side = tk.TOP, pady=(30,0))

radio10 = tk.Radiobutton(white_frame, image=percents[10], variable=white_var, value=10)
radio10.pack(side = tk.LEFT, padx=(0,200))
radio30 = tk.Radiobutton(white_frame, image=percents[30], variable=white_var, value=30)
radio30.pack(side = tk.LEFT)
#観測ボタン-----------------------------------------------------
watch_button = tk.Button(select_frame, text="観測", font=("Time New Roman", 15), command=observeMethod, state="disabled")
watch_button.pack(side = tk.TOP, pady=(30, 0))
turn_button = tk.Button(select_frame, text="手番を渡す", font=("Time New Roman", 15), command=turnMethod, state="disabled")
turn_button.pack(side = tk.TOP, pady=(30, 30))

re_button = tk.Button(select_frame, text="もう一度", font=("Time New Roman", 30), command=reMethod)
re_button.pack(side = tk.TOP, pady=(30, 30))
game_w.mainloop()